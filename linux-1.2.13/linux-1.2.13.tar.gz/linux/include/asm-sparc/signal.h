#ifndef _ASMSPARC_SIGNAL_H
#define _ASMSPARC_SIGNAL_H

struct sigcontext_struct {
	/*
	 * Have to find out what SUNOS and Solaris do. This could
	 * get real ugly. David S. Miller (davem@caip.rutgers.edu)
	 */
};

#endif
