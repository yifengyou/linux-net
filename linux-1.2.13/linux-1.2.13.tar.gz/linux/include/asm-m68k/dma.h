#ifndef _M68K_DMA_H
#define _M68K_DMA_H 1

/* dummy for m68k */

#endif /* _M68K_DMA_H */
